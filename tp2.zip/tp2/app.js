const express = require('express'); // Importer le module express 
const app = express(); // Créer une instance d'application Express 
const port = 3000; // Définir le port d'écoute 
// Définir la route pour la racine 
app.get('/', (req, res) => { 
res.send('Hello World!'); // Répondre avec "Hello World!" 
}); 
app.use(express.json());
app.use(express.urlencoded({ extended: true })); 
let users = [ 
    { id: 1, name: 'Alice', email: 'alice@example.com' }, 
    { id: 2, name: 'Bob', email: 'bob@example.com' } 
    ];
 app.get('/users', (req, res) => { 
        res.json(users); 
        });
// Écouter sur le port défini 
app.listen(port, () => {console.log(`Application exemple à l'écoute sur le port ${port}!`); 
}); 