const express=require('express');
const app=express();
//middleware de journalisation
const LoggerMiddle=(req,res,next)=>{
    const now=new Date();
    const date=now.toLocaleDateString();
    const time=now.toLocaleTimeString();
    console.log(`[${date} ${time}] ${req.method} ${req.path}`);
    next();
};
app.use(LoggerMiddle);
//utiliser le middleware dans l'application
app.get('/',(req,res)=>{
    res.send('Exercice1!');
});
app.listen(3000,()=>{
    console.log('Serveur démarré sur le port 3000');
});
app.get("/Exercice1",(req,res)=>{
    res.send("Une deuxiéme API");
});
