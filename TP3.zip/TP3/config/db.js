const { default: mongoose } = require("mongoose");



const uri=`mongodb+srv://admin:admin@cluster0.d3a5q.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`;
const connectDB=async()=>{
    try{
        await mongoose.connect(uri)
        .then(()=>console.log("Established connection to the database"));
        .catch(err=>console.log("Something wrong when connecting to the database"));
    }catch(error){
        console.error("Connection error at MongoDB",error.message);
        process.exit(1);
    }
};
module.exports=connectDB;